How to build a TypeScript bot

1. run `npm install`
2. Modify src/bot.ts, implement `getMoves` to return the next 5 moves given the current state.
3. Compile with `npm run tsc`
4. run with `node ./dist/bot.js [host] [port] [name] [persistent]`
