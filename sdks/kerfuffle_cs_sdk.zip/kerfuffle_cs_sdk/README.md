How to build a C# bot

Open kerfuffle_cs_sdk.sln in visual studio or mono develop
Modify Program.cs to implement your bot
