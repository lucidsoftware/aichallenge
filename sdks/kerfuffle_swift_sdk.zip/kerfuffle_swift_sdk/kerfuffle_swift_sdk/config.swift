var host = "localhost"
var port = 8080
var persistent = false
var name = "George"
