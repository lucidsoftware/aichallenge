Basic Usage:

Open the project in Xcode.  Run with "Product > Run"

Change the values in config.swift to point at the actual game server.

Edit the `getMoves(data:)` method in the class `MyBot`.

